from .helpers.render import render_component as component


__all__ = [
    "component",
]
